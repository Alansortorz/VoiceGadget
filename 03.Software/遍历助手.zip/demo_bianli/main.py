# -*- coding:utf-8 -*-
from PyQt5.Qt import QWidget,QApplication
from PyQt5.Qt import QIcon,QLabel,QLineEdit,QPushButton,QGroupBox
from PyQt5.Qt import QHBoxLayout,QVBoxLayout,QTextEdit,QRadioButton,QFileDialog,QMessageBox
import sys,os,time
from thread import My_Thread
from pathlib import Path

class Window(QWidget):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("遍历助手")
        self.setWindowIcon(QIcon("./images/logo.png"))
        self.resize(800,600)
        self.setup_ui()

    # 初始化UI和初始化方法
    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addLayout(self.init_src_dir())
        layout.addLayout(self.init_dst_dir())
        layout.addLayout(self.init_rbtn())
        layout.addLayout(self.init_start_stop())
        layout.addLayout(self.init_text_edit())
        self.setLayout(layout)

        # 初始化线程类，绑定信号事件
        self.t = My_Thread()
        self.t.signal_start.connect(self.update_text_edit)
        self.t.signal_end.connect(self.update_end_text_edit)

        # 绑定选择遍历路径事件
        self.src_btn.clicked.connect(self.btn_select_dir_cmd)

        # 绑定保存遍历信息事件
        self.dst_btn.clicked.connect(self.btn_save_dir_cmd)

        # 绑定开始遍历按钮事件
        self.btn_start.clicked.connect(self.start_cmd)

        # 绑定停止遍历事件
        self.btn_stop.clicked.connect(self.stop_cmd)

    # 初始化源文件夹相关
    def init_src_dir(self):
        layout = QHBoxLayout()
        self.src_label = QLabel("来源：")
        self.src_lineedit = QLineEdit()
        self.src_lineedit.setPlaceholderText("选择需要遍历的文件夹")
        self.src_btn = QPushButton("选择")
        layout.addWidget(self.src_label)
        layout.addWidget(self.src_lineedit)
        layout.addWidget(self.src_btn)
        return layout

    # 初始化目标文件夹相关
    def init_dst_dir(self):
        layout = QHBoxLayout()
        self.dst_label = QLabel("目标：")
        self.dst_lineedit = QLineEdit()
        self.dst_lineedit.setPlaceholderText(f"选择保存遍历信息文件夹")
        self.dst_btn = QPushButton("选择")
        layout.addWidget(self.dst_label)
        layout.addWidget(self.dst_lineedit)
        layout.addWidget(self.dst_btn)
        return layout

    # 初始化：【单选按钮】
    def init_rbtn(self):
        box = QHBoxLayout()
        groupbox = QGroupBox("遍历目标")
        layout = QHBoxLayout()

        self.dir_and_file = QRadioButton("文件夹和文件")
        self.dir = QRadioButton("文件夹")
        self.file = QRadioButton("文件")
        self.dir_and_file.setChecked(True)

        layout.addWidget(self.dir_and_file)
        layout.addWidget(self.dir)
        layout.addWidget(self.file)

        groupbox.setLayout(layout)
        box.addWidget(groupbox)
        return box

    # 初始化开始和停止按钮
    def init_start_stop(self):
        layout = QHBoxLayout()
        self.btn_start = QPushButton("开始")
        self.btn_stop = QPushButton("停止")
        layout.addWidget(self.btn_start)
        layout.addWidget(self.btn_stop)
        return layout

    # 初始化消息显示框
    def init_text_edit(self):
        layout = QVBoxLayout()
        self.text_edit = QTextEdit()
        layout.addWidget(self.text_edit)
        return layout

    # 事件：选择遍历文件夹事件
    def btn_select_dir_cmd(self):
        dir = QFileDialog.getExistingDirectory(self, "请选择文件夹", "./")
        self.src_lineedit.setText(dir)

    # 事件：保存遍历文件事件
    def btn_save_dir_cmd(self):
        dir = QFileDialog.getExistingDirectory(self, "请选择文件夹", "./")
        self.dst_lineedit.setText(dir)

    # 事件：获取单选按钮的值
    def get_radiobtn_value(self):
        if self.dir_and_file.isChecked():
            return 1
        if self.dir.isChecked():
            return 2
        if self.file.isChecked():
            return 3

    # 开始遍历
    def start_cmd(self):

        # 判断用户是否选择了文件夹
        if self.src_lineedit.text() == "" or self.dst_lineedit.text() == "":
            QMessageBox.information(self,"消息","请选择文件夹")
            return ""

        # 清空消息显示框
        self.text_edit.clear()

        # 设置按钮状态
        self.btn_start.setEnabled(False)

        # 获取需要遍历的目录
        dir = self.src_lineedit.text()

        # 获取单选按钮的值
        # 1：文件夹和文件
        # 2：文件夹
        # 3：文件
        type = self.get_radiobtn_value()

        temp_time = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
        filename = os.path.join(self.dst_lineedit.text(), f"{temp_time}.csv")
        filename = Path(filename)

        self.t.set_dirs(dir)
        self.t.set_type(type)
        self.t.set_filename(filename)
        self.t.flag = True
        self.t.start()

    # 停止遍历
    def stop_cmd(self):
        self.t.stop()

    # 遍历中更新文本框中的内容
    def update_text_edit(self,item):
        self.text_edit.append(item)

    # 遍历完成，更新文本框中的内容，初始化按钮状态
    def update_end_text_edit(self,item):
        self.text_edit.append(item)
        self.btn_start.setEnabled(True)

app = QApplication(sys.argv)
window = Window()
window.show()

qss = "* {font-family: 微软雅黑;}"
app.setStyleSheet(qss)

sys.exit(app.exec_())