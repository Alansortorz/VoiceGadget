# -*- coding:utf-8 -*-
import time
from PyQt5.Qt import pyqtSignal
from PyQt5.QtCore import QThread
from pathlib import Path

class My_Thread(QThread):
    signal_start = pyqtSignal(str)
    signal_end = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.flag = True
        self.dir = None
        self.type = None
        self.filename = None
        self.time_sleep = 0.002

    # 设置需要遍历的文件夹
    def set_dirs(self,dir):
        self.dir = rf"{dir}"

    # 设置需要遍历的类型（文件夹，文件，文件夹和文件）
    def set_type(self,type):
        self.type = type

    # 设置文件名
    def set_filename(self,filename):
        self.filename = filename

    # 如果number=1，遍历文件夹和文件
    def bianli_file_and_dir(self):
        res = Path(self.dir)
        for item in res.rglob("*"):
            if self.flag == True:
                # print(item)
                self.save_file(item)                # 将路径写入CSV文件
                self.signal_start.emit(str(item))   # 给界面发送信号，并且携带路径信息
            else:
                self.signal_end.emit(str("遍历停止"))
                return ""
            time.sleep(self.time_sleep)
        self.signal_end.emit(str("遍历完成"))

    # 如果number=2，遍历文件夹
    def bianli_dir(self):
        res = Path(self.dir)
        for item in res.rglob("**"):
            if self.flag == True:
                # print(item)
                self.save_file(item)  # 将路径写入CSV文件
                self.signal_start.emit(str(item))  # 给界面发送信号，并且携带路径信息
            else:
                self.signal_end.emit(str("遍历停止"))
                return ""
            time.sleep(self.time_sleep)
        self.signal_end.emit(str("遍历完成"))

    # 如果number=3，遍历文件
    def bianli_file(self):
        res = Path(self.dir)
        for item in res.rglob("*"):
            if self.flag == True:
                temp_item = Path(f"{item}")
                if temp_item.is_file():
                    # print(temp_item)
                    self.save_file(item)  # 将路径写入CSV文件
                    self.signal_start.emit(str(item))  # 给界面发送信号，并且携带路径信息
            else:
                self.signal_end.emit(str("遍历停止"))
                return ""
            time.sleep(self.time_sleep)
        self.signal_end.emit(str("遍历完成"))

    # 写入CSV文件
    def save_file(self, content):
        try:
            with open(self.filename, "a+", encoding='GBK') as f:
                f.write(f"{content} \n")
        except:
            print(f"*" * 100)
            print(f"错误文件名：{content}")
            print(f"*" * 100)

    # 停止任务
    def stop(self):
        self.flag = False

    # 执行程序
    def run(self):
        if self.type == 1:
            self.bianli_file_and_dir()
        if self.type == 2:
            self.bianli_dir()
        if self.type == 3:
            self.bianli_file()


if __name__ == '__main__':
    dirs = rf"\\cnsv1002\上海历史项目\2010-job\08-其他客户\ハウス"
    filename = "test.csv"
    type = 2
    t = My_Thread()
    t.set_dirs(dirs)
    t.set_type(type)
    t.set_filename(filename)
    t.run()