# -*- coding:utf-8 -*-
from PyQt5.Qt import *
import sys,pyttsx3,time

class Thread(QThread):
    signal_start = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.flag = True
        self.text = None
        self.start_event = None
        self.tts = pyttsx3.init()

    def set_text(self,text):
        self.text = text

    def run(self):
        if self.start_event == "replace":
            try:
                self.tts.say(self.text)
                self.tts.runAndWait()
                self.tts.stop()
                self.signal_start.emit(f"播放完成")
            except:
                self.signal_start.emit(f"播放失败")

        if self.start_event == "save":
            try:
                self.tts.save_to_file(self.text, f"./{self.text}.mp3")
                self.tts.runAndWait()
                self.tts.stop()
                time.sleep(1)
                self.signal_start.emit(f"保存成功")
            except:
                self.signal_start.emit(f"保存失败")

    def stop(self):
        self.flag = False

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.resize(800,600)
        self.setWindowTitle("文字转语音助手")
        self.setWindowIcon(QIcon("./images/logo.png"))
        self.btn_flag = True
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addLayout(self.init_text(),4)
        layout.addLayout(self.init_btns(),1)
        layout.addLayout(self.init_msg(),1)
        self.setLayout(layout)

        # 绑定按钮事件
        self.btn_replace.clicked.connect(self.btn_replace_cmd)
        self.btn_save.clicked.connect(self.btn_save_cmd)

        # 实例化线程类,将线程信号绑定到相应的槽函数
        self.t = Thread()
        self.t.signal_start.connect(self.thread_start_cmd)

    # 初始化文本框
    def init_text(self):
        layout = QHBoxLayout()
        self.text = QTextEdit()
        self.text.setStyleSheet("QTextEdit{font-family: 微软雅黑;font-size:18px;height:50px;}")
        self.text.setPlaceholderText("输入需要转换为语音的文字")
        layout.addWidget(self.text)
        return layout

    # 初始化播放和保存按钮
    def init_btns(self):
        layout = QHBoxLayout()
        self.btn_replace = QPushButton("转换并播放")
        self.btn_replace.setStyleSheet("QPushButton{font-family: 微软雅黑;font-size:14px;height:30px;}")
        self.btn_save = QPushButton("保存到文件")
        self.btn_save.setStyleSheet("QPushButton{font-family: 微软雅黑;font-size:14px;height:30px;}")
        layout.addWidget(self.btn_replace)
        layout.addWidget(self.btn_save)
        return layout

    # 初始信息显示框
    def init_msg(self):
        layout = QVBoxLayout()
        self.msg = QTextEdit()
        self.msg.setStyleSheet("QTextEdit{font-family: 微软雅黑;}")
        layout.addWidget(self.msg)
        return layout

    # 转换按钮事件
    def btn_replace_cmd(self):

        # 检测输入的网址是否为空
        if self.text.toPlainText() == "":
            msg = QMessageBox(self)
            msg.information(self, "消息", "转换内容不能为空")
            return None

        # 开始转换相关
        self.msg.clear()
        self.msg.setText(f"消息：播放中")
        text = self.text.toPlainText()
        self.t.set_text(text)
        self.t.start_event = "replace"
        self.t.start()

    # 保存按钮事件
    def btn_save_cmd(self):
        # 检测输入的网址是否为空
        if self.text.toPlainText() == "":
            msg = QMessageBox(self)
            msg.information(self, "消息", "转换内容不能为空")
            return None

        # 开始转换相关
        self.msg.clear()
        self.msg.setText(f"消息：保存中")
        text = self.text.toPlainText()
        self.t.set_text(text)
        self.t.start_event = "save"
        self.t.start()

    # 线程事件
    def thread_start_cmd(self,text):
        self.msg.append(f"消息：{text}")

app = QApplication(sys.argv)
window = Window()
window.show()
sys.exit(app.exec_())