# -*- coding:utf-8 -*-
# @作者：超级大兔子
# @简介：关机助手(定时关机）

from PyQt5.QtWidgets import QWidget,QApplication
from PyQt5.QtWidgets import QPushButton,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QLCDNumber,QSpinBox
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt,QThread,pyqtSignal
import sys,time,os

class My_Thread(QThread):
    signal_start = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.number = None
        self.flag = True

    def set_value(self,number):
        self.number = number

    def run(self):
        for item in range(self.number):
            if self.flag == True:
                self.number = self.number -1

                # 计算时分秒
                m,s = divmod(self.number,60)
                h,m = divmod(m, 60)
                msg = f"{h}:{m}:{s}"
                self.signal_start.emit(str(msg))

                time.sleep(1)
                print(item)

    def stop(self):
        self.flag = False

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("定时关机助手")
        self.setWindowIcon(QIcon("./images/logo.png"))
        self.setWindowFlags(Qt.WindowStaysOnTopHint)
        self.resize(400,300)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addLayout(self.init_ui(),1)
        layout.addLayout(self.init_lcd(),2)
        layout.addLayout(self.init_btn(),1)
        layout.addStretch()
        self.setLayout(layout)

        self.btn_start.clicked.connect(self.btn_start_cmd)
        self.btn_stop.clicked.connect(self.btn_stop_cmd)
        self.btn_reset.clicked.connect(self.btn_reset_cmd)

        self.t = My_Thread()
        self.t.signal_start.connect(self.res_cmd)

    def init_ui(self):
        layout = QHBoxLayout()
        self.le1 = QSpinBox()
        self.le1.setRange(0,99)
        self.le1.setSingleStep(1)
        shi = QLabel("小时")

        self.le2 = QSpinBox()
        self.le2.setRange(0,60)
        self.le2.setSingleStep(1)
        fen = QLabel("分钟")

        self.le3 = QSpinBox()
        self.le3.setRange(0,60)
        self.le3.setSingleStep(1)
        miao = QLabel("秒 后关机")

        layout.addWidget(self.le1)
        layout.addWidget(shi)
        layout.addWidget(self.le2)
        layout.addWidget(fen)
        layout.addWidget(self.le3)
        layout.addWidget(miao)
        return layout

    def init_lcd(self):
        layout = QHBoxLayout()
        self.lcd = QLCDNumber()
        self.lcd.setDigitCount(8)
        value = 0
        self.lcd.display(value)
        layout.addWidget(self.lcd)
        return layout

    def init_btn(self):
        layout = QHBoxLayout()
        self.btn_start = QPushButton("开始")
        self.btn_stop = QPushButton("停止")
        self.btn_reset = QPushButton("重置")
        layout.addWidget(self.btn_start)
        layout.addWidget(self.btn_stop)
        layout.addWidget(self.btn_reset)
        return layout

    def btn_start_cmd(self):
        if self.le1.value() == "":
            shi_value = 0
        else:
            shi_value = int(self.le1.value()) * 3600

        if self.le2.value() == "":
            fen_value = 0
        else:
            fen_value = int(self.le2.value()) * 60

        if self.le3.value() == "":
            miao_value = 0
        else:
            miao_value = int(self.le3.value())

        value = shi_value + fen_value + miao_value

        # value = 86400
        self.t.set_value(value)
        self.t.flag = True
        self.t.start()

    def btn_stop_cmd(self):
        self.t.stop()

    def btn_reset_cmd(self):
        self.le1.setValue(0)
        self.le2.setValue(0)
        self.le3.setValue(0)
        self.t.stop()
        self.lcd.display(0)

    def res_cmd(self,value):
        self.lcd.display(value)
        print(value)
        if value == "0:0:0":
            os.popen("shutdown /s /t 1")

app = QApplication(sys.argv)
window = Window()
window.show()

qss = '''
* {
    background-color: rgb(25,35,45);
    font-family: 微软雅黑;
    color: rgb(224,225,227)
}

QPushButton {
    background-color: rgb(69,83,100);
    border: 2px solid rgb(69,83,100);
    border-radius: 5px;
    padding: 3px;
    margin-top: 8px;
}
QPushButton:hover {
    background-color: rgb(84,104,122);
}
QPushButton:pressed {
    background-color: rgb(96,121,139);
}
QSpinBox {
    width: 80px;
    height: 30px;
    font-size: 24px;
}
'''
app.setStyleSheet(qss)
sys.exit(app.exec_())
