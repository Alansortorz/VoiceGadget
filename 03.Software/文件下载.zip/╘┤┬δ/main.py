# -*- coding:utf-8 -*-
# 作者：超级大兔子
# 简介：文件下载器

from PyQt5.Qt import *
import sys,requests,pathlib

class Thread(QThread):
    signal_pv = pyqtSignal(int)
    signal_end = pyqtSignal(int)

    def __init__(self):
        super().__init__()
        self.flag = True
        self.url = None

    def set_url(self,url):
        self.url = url

    def run(self):
        # 下载文件相关
        headers = {'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0'}
        res = requests.get(self.url, headers=headers, stream=True)
        tmp_url = res.url

        # 获取文件名
        filename = pathlib.Path(tmp_url).name

        # 获取文件大小
        file_size = float(res.headers['content-length'])

        # 当前已下载到的文件大小
        data_size = 0

        with open(filename, "wb") as f:
            for item in res.iter_content(chunk_size=1024):
                if self.flag:
                    f.write(item)
                    data_size = data_size + len(item)
                    p = data_size / file_size * 100
                    self.signal_pv.emit(int(p))
                    if p == 100:
                        self.signal_end.emit(int(100))

    def stop(self):
        self.flag = False

class Window(QWidget):
    def __init__(self):
        super().__init__()
        self.resize(600,300)
        self.setWindowTitle("文件下载器")
        self.setWindowIcon(QIcon("./images/logo.png"))
        self.btn_flag = True
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.addLayout(self.init_url_input())
        layout.addLayout(self.init_pgb())
        layout.addLayout(self.init_text())
        self.setLayout(layout)

        # 绑定按钮事件
        self.btn.clicked.connect(self.btn_cmd)

        # 实例化线程类,将线程信号绑定到相应的槽函数
        self.t = Thread()
        self.t.signal_pv.connect(self.thread_pv_cmd)
        self.t.signal_end.connect(self.thread_end_cmd)

    # 初始化下载地址输入框
    def init_url_input(self):
        layout = QHBoxLayout()

        self.url = QLabel("下载链接：")
        self.url.setStyleSheet("QLabel{font-family: 微软雅黑;}")

        self.url_input = QLineEdit()
        self.url_input.setText("")
        self.url_input.setStyleSheet("QLineEdit{font-family: 微软雅黑;}")
        self.url_input.setPlaceholderText("输入需要下载的文件链接地址")

        self.btn = QPushButton("开始下载")
        self.btn.setStyleSheet("QPushButton{font-family: 微软雅黑;}")

        layout.addWidget(self.url)
        layout.addWidget(self.url_input)
        layout.addWidget(self.btn)
        return layout

    # 初始化进度条类
    def init_pgb(self):
        layout = QHBoxLayout()

        self.download_text = QLabel("下载进度：")
        self.download_text.setStyleSheet("QLabel{font-family: 微软雅黑;}")

        self.pgb = QProgressBar(self)
        self.pgb.resize(300,30)
        self.pgb.setMinimum(0)
        self.pgb.setMaximum(100)
        self.pv = 0
        self.pgb.setValue(self.pv)
        self.pgb.setStyleSheet("QProgressBar{text-align:center;}")

        layout.addWidget(self.download_text)
        layout.addWidget(self.pgb)
        return layout

    # 初始化状态显示框
    def init_text(self):
        layout = QHBoxLayout()
        self.text = QTextEdit()
        layout.addWidget(self.text)
        return layout

    # 开始按钮事件
    def btn_cmd(self):

        # 检测输入的网址是否为空
        if self.url_input.text() == "":
            msg = QMessageBox(self)
            msg.information(self, "消息", "下载地址不能为空")
            print("消息：用户没有输入视频链接地址")
            return None

        if self.btn_flag == True:
            print("开始下载")
            self.btn.setText("停止下载")
            self.btn_flag = False

            # 显示状态信息
            url = self.url_input.text()
            filename = pathlib.Path(url).name
            self.text.setHtml(f'<div style="line-height:20px;font-family: 微软雅黑;">开始下载：{filename}</div>')

            # 开始线程下载任务
            self.t.set_url(url)
            self.t.flag = True
            self.t.start()
        else:
            print("停止下载")
            self.btn.setText("开始下载")
            self.btn_flag = True

            # 显示状态信息
            url = self.url_input.text()
            filename = pathlib.Path(url).name
            self.text.setHtml(f'<div style="line-height:20px;font-family: 微软雅黑;">停止下载：{filename}</div>')

            # 停止线程下载任务
            self.t.stop()

    # 实始化信号绑定的槽函数
    def thread_pv_cmd(self, number):
        self.pgb.setValue(number)

    # 实始化信号绑定的槽函数
    def thread_end_cmd(self, number):

        if number == 100:
            print(f"下载完成")
            self.btn.setText("开始下载")
            self.text.append(f'<div style="line-height:20px;font-family: 微软雅黑;">下载完成</div>')
            self.btn_flag = True

app = QApplication(sys.argv)
window = Window()
window.show()
sys.exit(app.exec_())